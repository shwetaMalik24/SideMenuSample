//
//  MenuViewController.swift
//  SideMenuSample
//
//  Created by Drish on 22/05/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

enum MODULES: Int {
    
    case Home = 0
    case Profile
    case Setting

}
class MenuViewController: UIViewController, UITableViewDelegate , UITableViewDataSource
{
@IBOutlet var tableViewMenu: UITableView!
  var array = ["Home","My Profile","Settings"]
var modulesArray = [LeftMenuModel]()
var didTapMenuType: ((MODULES) -> Void)?
var selectedIndex : Int?
 override func viewDidLoad()
    {
        super.viewDidLoad()
        tableViewMenu.delegate = self
        tableViewMenu.dataSource = self
        self.tableViewMenu.rowHeight = UITableView.automaticDimension
        self.tableViewMenu.estimatedRowHeight = 44
        
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                guard let menuType = MODULES(rawValue: indexPath.row) else { return }
                dismiss(animated: true) { [weak self] in
                    print("Dismissing: \(menuType)")
                    self?.didTapMenuType?(menuType)

    }
    }
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
            print(modulesArray)
            return array.count
        }
      func numberOfSections(in tableView: UITableView) -> Int {
          return 1
      }
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = tableViewMenu.dequeueReusableCell(withIdentifier: "Cell") as! leftMenuCell
        cell.lblTitleMenu?.text = array[indexPath.row]
          
          return cell
      }
    func tableView(tableView: UITableView,heightForFooterInSection section: Int) -> CGFloat {
         return 1
    }
    }


