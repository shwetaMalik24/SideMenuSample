//
//  HomeViewController.swift
//  SideMenuSample
//
//  Created by Drish on 22/05/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    let transiton = SlideInTransition()
      var topView: UIView?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnMenu(_ sender: Any)  {
            guard let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuVC") as? MenuViewController else { return }
              menuViewController.didTapMenuType = { MODULES in
                        self.transitionToNew(MODULES)
                    }
              menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self as UIViewControllerTransitioningDelegate
              present(menuViewController, animated: true)
          }
            func transitionToNew(_ menuType: MODULES)
            {
                  let title = String(describing: menuType).capitalized
                  switch menuType
                  {
                  case .Home:
                    let vc = self.storyboard?.instantiateViewController(identifier: "homeVC") as? UINavigationController
                        self.view.window?.rootViewController = vc
                    break
                   
                 
                  case .Profile:
                      let vc = self.storyboard?.instantiateViewController(identifier: "profileVC") as? UINavigationController
                                          self.view.window?.rootViewController = vc
                    break
                  case .Setting:
                    let vc = self.storyboard?.instantiateViewController(identifier: "settingVC") as? UINavigationController
                                                             self.view.window?.rootViewController = vc
                    break
                  default:
                      break
                  }
              }
          }
    //Extentions
    extension HomeViewController: UIViewControllerTransitioningDelegate {
              func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
                  transiton.isPresenting = true
                return transiton
              }

              func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
                  transiton.isPresenting = false
                return transiton 
              }
          }


