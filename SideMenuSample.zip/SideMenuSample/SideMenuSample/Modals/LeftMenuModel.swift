//
//  LeftMenuModel.swift
//  SideMenuSample
//
//  Created by Drish on 22/05/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class LeftMenuModel: NSObject {
    var moduleName: String?
      var moduleImage = UIImage()

      override init() {
          super.init()
      }

      required init(data: [String:AnyObject]) {
          
          if let val = data["name"] as? String{
              self.moduleName = val
          }
          if let val = data["image"] as? UIImage{
              self.moduleImage = val
          }
      }
}
