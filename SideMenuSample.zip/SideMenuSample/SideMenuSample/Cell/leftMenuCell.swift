//
//  leftMenuCell.swift
//  SideMenuSample
//
//  Created by Drish on 22/05/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class leftMenuCell: UITableViewCell {

    @IBOutlet var lblTitleMenu: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
